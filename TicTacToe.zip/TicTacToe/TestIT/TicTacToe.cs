﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestIT
{
    class TicTacToe
    {
        int _player = 0;

        public void Check(Button button, ListBox panel)
        {
            if (button.Text == string.Empty)
            {
                if (_player%2 == 0)
                {
                    button.Text = "X";
                    _player++;
                    panel.Items.Add("Randul lui O");
                }
                else
                {
                    button.Text = "O";
                    _player++;
                    panel.Items.Add("Randul lui X");
                }
            }
        }

        private int[,] Winners =
        {
            {0, 1, 2},
            {3, 4, 5},
            {6, 7, 8},
            {0, 3, 6},
            {1, 4, 7},
            {2, 5, 8},
            {0, 4, 8},
            {2, 4, 6}
        };

        private void ResetGame(Button[] buttons, ListBox panel)
        {
            _player = 0;
            for (int i = 0; i < 9; i++)
            {
                buttons[i].BackColor = Color.White;
                buttons[i].Text = string.Empty;
            }
            panel.Items.Clear();
            panel.Items.Add("Randul lui X");
        }

        public void CheckForWinner(Button[] buttons, ListBox panel)
        {
            for (int i = 0; i < 8; i++)
            {
                int x = Winners[i, 0], y = Winners[i, 1], z = Winners[i, 2];
                Button b1 = buttons[x], b2 = buttons[y], b3 = buttons[z];
                if (b1.Text == b2.Text && b1.Text == b3.Text && b1.Text == string.Empty) continue;
                if (b1.Text == b2.Text && b1.Text == b3.Text)
                {
                    b1.BackColor = Color.Chocolate;
                    b2.BackColor = Color.Chocolate;
                    b3.BackColor = Color.Chocolate;
                    if (_player%2 == 0)
                    {
                        MessageBox.Show("O-ul a castigat");
                        ResetGame(buttons,panel);
                    }
                    else
                    {
                        MessageBox.Show("X-ul a castigat");
                        ResetGame(buttons,panel);
                    }

                }
            }
            if (_player == 9)
            {
                ResetGame(buttons,panel);
            }
        }

    }
}
