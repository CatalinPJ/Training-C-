﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestIT
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void AfiseazaMesaj()
        {
            Button btn = new Button()
            {
                Width = 200,
                Height = 70,
                Text="Test"
            };
            //btn.Click += Btn_Click;
            btn.DoubleClick += Btn_DoubleClick;
            Controls.Add(btn);

        }

        private void Btn_DoubleClick(object sender, EventArgs e)
        {
            MessageBox.Show("Double click");
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        TicTacToe ttt=new TicTacToe();
        private void button1_Click(object sender, EventArgs e)
        {
            Button[] buttons = {button1, button2, button3, button4, button5, button6, button7, button8, button9};
            ttt.Check((sender as Button), listBox1);
            ttt.CheckForWinner(buttons, listBox1);
        }
    }
}
