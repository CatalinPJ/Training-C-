﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace NewThreads
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
           // for(int i=0;i<pictureBox1.Width;i++)
             //   for (int j = 0; j < pictureBox1.Height; j++)
               //     richTextBox1.AppendText((((Bitmap) (pictureBox1.Image)).GetPixel(i, j)).ToString() + 
                 //       Environment.NewLine);

            new Thread(() =>
            {
              for(int i=0;i<pictureBox1.Width;i++)
                  for (int j = 0; j < pictureBox1.Height; j++)
                  {
                      richTextBox1.Invoke((Action) delegate
                      {
                          richTextBox1.AppendText((((Bitmap)(pictureBox1.Image)).GetPixel(i, j)).ToString() +
                        Environment.NewLine);
                      });
                  }  
            }).Start();

        }
    }
}
